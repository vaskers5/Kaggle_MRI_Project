# Kaggle_MRI_Project
 Trying to fix myself
